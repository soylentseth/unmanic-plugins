
**<span style="color:#56adda">1.1.5</span>**
- Fix issue where the default track would still be set after a reorder

**<span style="color:#56adda">1.1.4</span>**
- Update FFmpeg helper
- Add platform declaration

**<span style="color:#56adda">1.1.3</span>**
- Update Plugin for Unmanic v2 PluginHandler compatibility

**<span style="color:#56adda">1.1.2</span>**
- Fix Python bug in stream mapping 

**<span style="color:#56adda">1.1.1</span>**
- Limit plugin to only process files with a "video" mimetype

**<span style="color:#56adda">1.1.0</span>**
- Update Plugin for Unmanic v1 PluginHandler compatibility
- Update icon

**<span style="color:#56adda">1.0.0</span>**
- Add library scanner file test - Add files that have streams to be re-ordered

**<span style="color:#56adda">0.0.4</span>**
- Keep the output file out in the same container as the source

**<span style="color:#56adda">0.0.3</span>**
- Fix up issue caused by tags having only a title or language
- Tidy up plugin code

**<span style="color:#56adda">0.0.2</span>**
- Fix mistake in subtitle track counter

**<span style="color:#56adda">0.0.1</span>**
- Initial version
