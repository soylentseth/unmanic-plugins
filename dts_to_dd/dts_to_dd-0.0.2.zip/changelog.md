
**<span style="color:#56adda">0.0.2</span>**
- Update Plugin for Unmanic v1 PluginHandler compatibility
- Add icon

**<span style="color:#56adda">0.0.1</span>**
- Initial version
